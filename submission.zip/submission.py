"""
Auto-generated submission module from a Jupyter notebook.

This file is intended to be imported by the EvalAI evaluation script.
It should define your model class(es) and a function:

    run_test_submit(data_root='dataset', img_size=100, batch_size=64,
                    load_path="checkpoints/model_final.npz", model_cls=None, strict=True) -> float

which returns Accuracy in [0, 1].
"""
# (Auto-inserted standard imports in case the notebook relied on them implicitly)
import os, time, json, math, random
from typing import List, Tuple, Dict, Any
import numpy as np
from PIL import Image
from tqdm import tqdm


import os, time, random

from typing import List, Tuple

import numpy as np

from PIL import Image

from tqdm import tqdm

import json

SEED = 42

IMG_SIZE = 100

def linear_layer(x, W, theta):
    return np.dot(x, W) + theta

def conv2d(X: np.ndarray, kernel: np.ndarray) -> np.ndarray:
    assert X.ndim == 2
    assert kernel.ndim == 2 and kernel.shape[0] == kernel.shape[1]
    H, W = X.shape
    k = kernel.shape[0]
    H_out = H - k + 1
    W_out = W - k + 1
    Y = np.zeros((H_out, W_out), dtype=np.float32)
    for i in range(H_out):
        for j in range(W_out):
            Y[i, j] = np.sum(X[i:i + k, j:j + k] * kernel)
    return Y

def ReLU(X: np.ndarray) -> np.ndarray:
    return np.maximum(0, X)

def max_pool2d(X: np.ndarray, k: int=2) -> np.ndarray:
    assert X.ndim == 2
    H, W = X.shape
    H_out = H // k
    W_out = W // k
    Y = np.zeros((H_out, W_out), dtype=np.float32)
    for i in range(H_out):
        for j in range(W_out):
            Y[i, j] = np.max(X[i * k:(i + 1) * k, j * k:(j + 1) * k])
    return Y

def mse_loss(y_pred: np.ndarray, y_true: np.ndarray):
    """
    MSE + gradient w.r.t y_pred
    y_pred, y_true:(N, d_out)
    """
    N = y_pred.shape[0]
    diff = y_pred - y_true
    loss = np.sum(diff * diff) / (2.0 * N)
    dY = diff / N
    return (loss, dY)

def backward(dY, x, W):
    dW = np.dot(x.T, dY)
    dTheta = np.sum(dY, axis=0)
    dX = np.dot(dY, W.T)
    return (dW, dTheta, dX)

def update_params(W, theta, dW, dTheta, lr=0.01):
    W_new = W - lr * dW
    theta_new = theta - lr * dTheta
    return (W_new, theta_new)

def relu_backward(dY, X):
    return dY * (X > 0)

def pad2d_zero(X, pad_top, pad_bottom, pad_left, pad_right):
    """Zero-pad a 2D array."""
    H, W = X.shape
    Y = np.zeros((H + pad_top + pad_bottom, W + pad_left + pad_right), dtype=X.dtype)
    Y[pad_top:pad_top + H, pad_left:pad_left + W] = X
    return Y

def conv2d_multi_forward_basic(XN, K):
    """
    Forward pass for multiple filters applied to a single-channel input.
    Uses only the basic conv2d().

    XN: (N, H, W)     batch of single-channel images
    K:  (F, k, k)     filters
    Returns:
        Y: (N, H-k+1, W-k+1, F)
        cache for backward
    """
    N, H, W = XN.shape
    F, k, _ = K.shape
    H_out, W_out = (H - k + 1, W - k + 1)
    Y = np.zeros((N, H_out, W_out, F), dtype=np.float32)
    for n in range(N):
        for f in range(F):
            Y[n, :, :, f] = conv2d(XN[n], K[f])
    cache = (XN, K)
    return (Y, cache)

def conv2d_multi_backward_basic(dY, cache):
    """
    Backward pass for conv2d_multi_forward_basic, using only conv2d().
    dK[f] = sum_n conv2d(XN[n], dY[n, :, :, f])
    dX[n] = sum_f conv2d( padded(dY[n, :, :, f]), rot180(K[f]) )

    dY: (N, H_out, W_out, F)
    Returns:
        dX: (N, H, W)
        dK: (F, k, k)
    """
    XN, K = cache
    N, H, W = XN.shape
    F, k, _ = K.shape
    H_out, W_out, _ = dY.shape[1:]
    dK = np.zeros_like(K, dtype=np.float32)
    for f in range(F):
        for n in range(N):
            dK[f] += conv2d(XN[n], dY[n, :, :, f])
    dX = np.zeros_like(XN, dtype=np.float32)
    for n in range(N):
        for f in range(F):
            kflip = np.flip(np.flip(K[f], axis=0), axis=1)
            pad = k - 1
            dYpad = pad2d_zero(dY[n, :, :, f], pad, pad, pad, pad)
            dX[n] += conv2d(dYpad, kflip)
    return (dX, dK)

def maxpool2d_forward_basic(XN, k=2):
    """
    Forward pass of max-pooling using the basic max_pool2d.
    Builds an argmax mask for backward.

    XN: (N, H, W, C) or (N, H, W)
    Returns:
        Y: pooled output
        mask: boolean mask for backward
    """
    if XN.ndim == 3:
        XN = XN[..., None]
    N, H, W, C = XN.shape
    H_out, W_out = (H // k, W // k)
    Y = np.zeros((N, H_out, W_out, C), dtype=np.float32)
    mask = np.zeros_like(XN, dtype=bool)
    for n in range(N):
        for c in range(C):
            Y[n, :, :, c] = max_pool2d(XN[n, :, :, c], k=k)
            for i in range(H_out):
                for j in range(W_out):
                    window = XN[n, i * k:(i + 1) * k, j * k:(j + 1) * k, c]
                    idx = np.unravel_index(np.argmax(window), (k, k))
                    mask[n, i * k + idx[0], j * k + idx[1], c] = True
    return (Y, mask)

def maxpool2d_backward_basic(dY, mask, k=2):
    """Backward pass for max-pooling using the saved mask."""
    if dY.ndim == 3:
        dY = dY[..., None]
    N, H, W, C = mask.shape
    H_out, W_out = dY.shape[1:3]
    dX = np.zeros(mask.shape, dtype=np.float32)
    for n in range(N):
        for c in range(C):
            for i in range(H_out):
                for j in range(W_out):
                    window_mask = mask[n, i * k:(i + 1) * k, j * k:(j + 1) * k, c]
                    dX[n, i * k:(i + 1) * k, j * k:(j + 1) * k, c][window_mask] = dY[n, i, j, c]
    if dX.shape[-1] == 1:
        dX = dX[..., 0]
    return dX

def conv2d_mimo_forward_basic(XNHWC, K):
    """
    Multi-input, multi-output convolution using only basic conv2d.

    XNHWC: (N, H, W, C_in)
    K:      (C_out, k, k, C_in)
    Returns:
        Y: (N, H-k+1, W-k+1, C_out)
        cache for backward
    """
    if XNHWC.ndim == 3:
        XNHWC = XNHWC[..., None]
    N, H, W, C_in = XNHWC.shape
    C_out, k, _, CinK = K.shape
    assert CinK == C_in
    H_out, W_out = (H - k + 1, W - k + 1)
    Y = np.zeros((N, H_out, W_out, C_out), dtype=np.float32)
    for n in range(N):
        for co in range(C_out):
            acc = np.zeros((H_out, W_out), dtype=np.float32)
            for ci in range(C_in):
                acc += conv2d(XNHWC[n, :, :, ci], K[co, :, :, ci])
            Y[n, :, :, co] = acc
    cache = (XNHWC, K)
    return (Y, cache)

def conv2d_mimo_backward_basic(dY, cache):
    """
    Backward for multi-input multi-output conv, using only conv2d.
    For each output channel co:
        dK[co, :, :, ci] = sum_n conv2d(X[n, ci], dY[n, co])
        dX[n, :, :, ci] += conv2d(padded(dY[n, co]), rot180(K[co, :, :, ci]))
    """
    X, K = cache
    if X.ndim == 3:
        X = X[..., None]
    N, H, W, C_in = X.shape
    C_out, k, _, CinK = K.shape
    assert CinK == C_in
    H_out, W_out, CoutDY = dY.shape[1:]
    assert CoutDY == C_out
    dK = np.zeros_like(K, dtype=np.float32)
    dX = np.zeros_like(X, dtype=np.float32)
    for co in range(C_out):
        for ci in range(C_in):
            for n in range(N):
                dK[co, :, :, ci] += conv2d(X[n, :, :, ci], dY[n, :, :, co])
    pad = k - 1
    for n in range(N):
        for co in range(C_out):
            dYpad = pad2d_zero(dY[n, :, :, co], pad, pad, pad, pad)
            for ci in range(C_in):
                kflip = np.flip(np.flip(K[co, :, :, ci], axis=0), axis=1)
                dX[n, :, :, ci] += conv2d(dYpad, kflip)
    if dX.shape[-1] == 1:
        dX = dX[..., 0]
    return (dX, dK)

def softmax(z: np.ndarray) -> np.ndarray:
    z = z - z.max(axis=1, keepdims=True)
    ez = np.exp(z, dtype=np.float32)
    return ez / (np.sum(ez, axis=1, keepdims=True) + 1e-12)

def cross_entropy_loss(probs: np.ndarray, y_true_idx: np.ndarray):
    """
    probs: (N, C) after softmax
    y_true_idx: (N,) integer labels
    returns (loss, grad_logits)
    """
    N = probs.shape[0]
    logp = -np.log(probs[np.arange(N), y_true_idx] + 1e-12)
    loss = float(np.mean(logp))
    grad = probs.copy()
    grad[np.arange(N), y_true_idx] -= 1.0
    grad /= N
    return (loss, grad)

def accuracy_from_logits(logits: np.ndarray, y_true_idx: np.ndarray) -> float:
    pred = np.argmax(softmax(logits), axis=1)
    return float(np.mean(pred == y_true_idx))

def list_images(root: str) -> Tuple[list, list]:
    classes = sorted([d for d in os.listdir(root) if os.path.isdir(os.path.join(root, d))])
    items = []
    for ci, cname in enumerate(classes):
        cdir = os.path.join(root, cname)
        for fn in os.listdir(cdir):
            if fn.lower().endswith(('.jpg', '.jpeg', '.png', '.bmp')):
                items.append((os.path.join(cdir, fn), ci))
    return (items, classes)

def load_batch(paths_labels, start, end, img_size=IMG_SIZE, augment=False):
    batch = paths_labels[start:end]
    N = len(batch)
    X = np.zeros((N, img_size, img_size), dtype=np.float32)
    y = np.zeros((N,), dtype=np.int64)
    for i, (p, lab) in enumerate(batch):
        img = Image.open(p).convert('L')
        if augment:
            if random.random() < 0.5:
                img = img.transpose(Image.FLIP_LEFT_RIGHT)
            if random.random() < 0.3:
                angle = random.uniform(-10, 10)
                img = img.rotate(angle, resample=Image.BILINEAR, fillcolor=0)
        img = img.resize((img_size, img_size), Image.BILINEAR)
        X[i] = np.asarray(img, dtype=np.float32) / 255.0
        y[i] = lab
    return (X, y)

def state_dict(model):
    """
    Collect all top-level numpy array attributes from the model.
    Returns a dict: {name: np.ndarray}
    """
    sd = {}
    for name, val in vars(model).items():
        if isinstance(val, np.ndarray):
            sd[name] = val
    return sd

def load_state_dict(model, state, strict=True):
    """
    Load arrays from `state` (a dict of name->ndarray) into model attributes.
    If strict=True, raises on missing keys or shape mismatch.
    Returns a report dict.
    """
    report = {'loaded': [], 'missing_in_model': [], 'missing_in_state': [], 'shape_mismatch': []}
    model_vars = vars(model)
    for k, arr in state.items():
        if k not in model_vars:
            report['missing_in_model'].append(k)
            if strict:
                raise KeyError(f"Parameter '{k}' not found in model.")
            continue
        if not isinstance(model_vars[k], np.ndarray):
            report['shape_mismatch'].append((k, 'not an ndarray on model'))
            if strict:
                raise TypeError(f"Model attribute '{k}' is not an ndarray.")
            continue
        if model_vars[k].shape != arr.shape:
            report['shape_mismatch'].append((k, (model_vars[k].shape, arr.shape)))
            if strict:
                raise ValueError(f"Shape mismatch for '{k}': model {model_vars[k].shape} vs state {arr.shape}")
        setattr(model, k, arr.astype(model_vars[k].dtype, copy=True))
        report['loaded'].append(k)
    for k, v in model_vars.items():
        if isinstance(v, np.ndarray) and k not in state:
            report['missing_in_state'].append(k)
    return report

def save_model(model, classes, path='checkpoints/model_final.npz', extra_meta=None):
    """
    Save model parameters (all top-level ndarrays) and metadata into a .npz file.
    """
    os.makedirs(os.path.dirname(path) or '.', exist_ok=True)
    sd = state_dict(model)
    meta = {'model_class': model.__class__.__name__, 'img_size': getattr(model, 'img_size', None), 'num_classes': getattr(model, 'num_classes', None), 'lr': getattr(model, 'lr', None), 'timestamp': time.strftime('%Y-%m-%d %H:%M:%S'), 'classes': classes}
    if extra_meta:
        meta.update(extra_meta)
    np.savez(path, **sd, meta=np.array([json.dumps(meta)], dtype=object))
    print(f'💾 Saved {len(sd)} tensors to {path}')
    return {'num_tensors': len(sd), 'path': path, 'meta': meta}

def load_model(path, model=None, model_ctor=None, ctor_kwargs=None, strict=True):
    """
    Load a saved .npz. If `model` is None, instantiate via `model_ctor(**ctor_kwargs)`.
    Returns (model, meta, report).
    """
    data = np.load(path, allow_pickle=True)
    meta = {}
    if 'meta' in data.files:
        try:
            meta = json.loads(str(data['meta'][0]))
        except Exception:
            pass
    state = {k: data[k] for k in data.files if k != 'meta'}
    if model is None:
        if model_ctor is None:
            raise ValueError('Provide either an existing `model` or a `model_ctor` to instantiate.')
        ctor_kwargs = dict(ctor_kwargs or {})
        for key in ('img_size', 'num_classes', 'lr'):
            if key in meta and key not in ctor_kwargs and (meta[key] is not None):
                ctor_kwargs[key] = meta[key]
        model = model_ctor(**ctor_kwargs)
    report = load_state_dict(model, state, strict=strict)
    print(f"✅ Loaded model from {path} | tensors loaded: {len(report['loaded'])}")
    if report['missing_in_model']:
        print(f"… skipped (missing in model): {report['missing_in_model']}")
    if report['missing_in_state']:
        print(f"… missing in state (kept init): {report['missing_in_state']}")
    if report['shape_mismatch']:
        print(f"… shape mismatch: {report['shape_mismatch']}")
    return (model, meta, report)

class SmallCNN:

    def __init__(self, img_size: int, num_classes: int, lr: float=0.01, f1: int=8, f2: int=16, k1: int=5, k2: int=5, fc_hidden: int=64):
        self.img_size = img_size
        self.num_classes = num_classes
        self.lr = lr
        self.f1, self.f2 = (f1, f2)
        self.k1, self.k2 = (k1, k2)
        self.fc_hidden = fc_hidden
        self.K1 = np.random.randn(f1, k1, k1).astype(np.float32) * np.sqrt(2.0 / (k1 * k1))
        self.K2 = np.random.randn(f2, k2, k2, f1).astype(np.float32) * np.sqrt(2.0 / (k2 * k2 * f1))
        s1 = img_size - k1 + 1
        s1p = s1 // 2
        s2 = s1p - k2 + 1
        s2p = s2 // 2
        self.flat_dim = s2p * s2p * f2
        self.W1 = np.random.randn(self.flat_dim, fc_hidden).astype(np.float32) * np.sqrt(2.0 / self.flat_dim)
        self.b1 = np.zeros((fc_hidden,), dtype=np.float32)
        self.W2 = np.random.randn(fc_hidden, num_classes).astype(np.float32) * np.sqrt(2.0 / fc_hidden)
        self.b2 = np.zeros((num_classes,), dtype=np.float32)

    def forward(self, X):
        C1, cache1 = conv2d_multi_forward_basic(X, self.K1)
        A1 = ReLU(C1)
        P1, mask1 = maxpool2d_forward_basic(A1, k=2)
        C2, cache2 = conv2d_mimo_forward_basic(P1, self.K2)
        A2 = ReLU(C2)
        P2, mask2 = maxpool2d_forward_basic(A2, k=2)
        Flt = P2.reshape(X.shape[0], -1)
        Z1 = linear_layer(Flt, self.W1, self.b1)
        A3 = ReLU(Z1)
        Z2 = linear_layer(A3, self.W2, self.b2)
        cache = (X, C1, A1, P1, mask1, cache1, C2, A2, P2, mask2, cache2, Flt, Z1, A3, Z2)
        return (Z2, cache)

    def backward(self, dlogits, cache):
        X, C1, A1, P1, mask1, cache1, C2, A2, P2, mask2, cache2, Flt, Z1, A3, Z2 = cache
        dW2, db2, dA3 = backward(dlogits, A3, self.W2)
        dZ1 = relu_backward(dA3, Z1)
        dW1, db1, dFlt = backward(dZ1, Flt, self.W1)
        dP2 = dFlt.reshape(P2.shape)
        dA2 = maxpool2d_backward_basic(dP2, mask2, k=2)
        dC2 = relu_backward(dA2, C2)
        dP1, dK2 = conv2d_mimo_backward_basic(dC2, cache2)
        dA1 = maxpool2d_backward_basic(dP1, mask1, k=2)
        dC1 = relu_backward(dA1, C1)
        dX, dK1 = conv2d_multi_backward_basic(dC1, cache1)
        self.W2, self.b2 = update_params(self.W2, self.b2, dW2, db2, lr=self.lr)
        self.W1, self.b1 = update_params(self.W1, self.b1, dW1, db1, lr=self.lr)
        self.K2 -= self.lr * dK2
        self.K1 -= self.lr * dK1

def accuracy(logits, y):
    preds = np.argmax(softmax(logits), axis=1)
    return float(np.mean(preds == y))

def train_eval(data_root='dataset_small', img_size=100, batch_size=32, epochs=10, lr=0.01, use_augment=True, model_cls=None, save_path='checkpoints/model_final.npz'):
    train_items, classes = list_images(os.path.join(data_root, 'train'))
    val_items, _ = list_images(os.path.join(data_root, 'val'))
    num_classes = len(classes)
    print(f'Classes: {classes} (num_classes={num_classes})')
    if model_cls is None:
        model_cls = SmallCNN
    model = model_cls(img_size=img_size, num_classes=num_classes, lr=lr)
    t0_total = time.time()
    last_train_loss, last_val_loss = (None, None)
    save_dir = 'checkpoints'
    os.makedirs(save_dir, exist_ok=True)
    timestamp = time.strftime('%Y%m%d_%H%M%S')
    save_name = f'{model_cls}_{os.path.basename(data_root)}_e{epochs}_{timestamp}.npz'
    save_path = os.path.join(save_dir, save_name)
    print(f'[info] Model will be saved to: {save_path}')
    for ep in range(1, epochs + 1):
        print(f'\n=== Epoch {ep}/{epochs} ===')
        random.shuffle(train_items)
        t0 = time.time()
        loss_accum, acc_accum, seen = (0.0, 0.0, 0)
        pbar = tqdm(range(0, len(train_items), batch_size), desc=f'Train {ep}', ncols=80)
        for s in pbar:
            X, y = load_batch(train_items, s, min(s + batch_size, len(train_items)), img_size, augment=use_augment)
            logits, cache = model.forward(X)
            probs = softmax(logits)
            loss, dlogits = cross_entropy_loss(probs, y)
            model.backward(dlogits, cache)
            acc = accuracy(logits, y)
            bsz = X.shape[0]
            loss_accum += loss * bsz
            acc_accum += acc * bsz
            seen += bsz
            pbar.set_postfix(loss=f'{loss:.3f}', acc=f'{acc * 100:.1f}%')
        last_train_loss = loss_accum / max(1, seen)
        train_time = time.time() - t0
        print(f'Epoch {ep:02d} Train: loss={last_train_loss:.4f}, acc={acc_accum / seen:.3f}, time={train_time:.1f}s')
        t1 = time.time()
        val_loss, val_acc, vseen = (0.0, 0.0, 0)
        pbar_val = tqdm(range(0, len(val_items), batch_size), desc=f'Val {ep}', ncols=80)
        for s in pbar_val:
            Xv, yv = load_batch(val_items, s, min(s + batch_size, len(val_items)), img_size, augment=False)
            logits, _ = model.forward(Xv)
            probs = softmax(logits)
            l, _ = cross_entropy_loss(probs, yv)
            a = accuracy(logits, yv)
            bsz = Xv.shape[0]
            val_loss += l * bsz
            val_acc += a * bsz
            vseen += bsz
            pbar_val.set_postfix(loss=f'{l:.3f}', acc=f'{a * 100:.1f}%')
        last_val_loss = val_loss / max(1, vseen)
        val_time = time.time() - t1
        print(f'Epoch {ep:02d} Val  : loss={last_val_loss:.4f}, acc={val_acc / vseen:.3f}, time={val_time:.1f}s')
    total_time = time.time() - t0_total
    print(f'\n✅ Training finished in {total_time / 60:.2f} minutes.')
    print(f'🔚 Final losses — train: {last_train_loss:.4f}, val: {last_val_loss:.4f}')
    if save_path:
        save_model(model, classes, path=save_path, extra_meta={'best_val_loss': float(last_val_loss), 'final_train_loss': float(last_train_loss), 'data_root': data_root})
    return (model, classes, {'final_train_loss': last_train_loss, 'final_val_loss': last_val_loss})

def run_test_submit(data_root='dataset_small', img_size=100, batch_size=64, load_path='checkpoints/model_final.npz', model_cls=None, strict=True):
    """
    Load a trained model and evaluate it on data_root/test.
    If test/ has subfolders (class names), computes accuracy.
    Otherwise just runs inference and reports number of samples.
    """
    if model_cls is None:
        model_cls = SmallCNN
    model, meta, report = load_model(load_path, model_ctor=model_cls, ctor_kwargs={'img_size': img_size}, strict=strict)
    classes_meta = meta.get('classes', None)
    test_dir = os.path.join(data_root, 'val')
    if not os.path.exists(test_dir):
        raise FileNotFoundError(f'Test directory not found: {test_dir}')
    if any((os.path.isdir(os.path.join(test_dir, d)) for d in os.listdir(test_dir))):
        test_items, classes_disk = list_images(test_dir)
        classes = classes_meta if classes_meta else classes_disk
        cls_to_idx = {c: i for i, c in enumerate(classes)}
        y_true = np.array([cls_to_idx[os.path.basename(os.path.dirname(p))] for p, _ in test_items], dtype=np.int32)
    else:
        test_items = [(os.path.join(test_dir, f), -1) for f in os.listdir(test_dir)]
        classes = classes_meta if classes_meta else []
        y_true = None
    print(f'Loaded model from {load_path}')
    print(f'Test samples: {len(test_items)}, labeled={y_true is not None}')
    if classes:
        print(f'Classes ({len(classes)}): {classes}')
    logits_list = []
    for s in tqdm(range(0, len(test_items), batch_size), desc='Infer', ncols=80):
        X, _ = load_batch(test_items, s, min(s + batch_size, len(test_items)), img_size, augment=False)
        logits, _ = model.forward(X)
        logits_list.append(logits)
    logits = np.concatenate(logits_list, axis=0)
    probs = softmax(logits)
    preds = np.argmax(probs, axis=1)
    if y_true is not None and len(y_true) == len(preds):
        acc = float((preds == y_true).mean())
        print(f'📊 Test accuracy: {acc:.4f}')
    else:
        acc = None
        print('📊 Test set appears unlabeled — accuracy not computed.')
    return acc

def main(mode='train', data_root='dataset_cropped', img_size=100, batch_size=32, epochs=10, lr=0.01, use_augment=True, model_cls=None, save_path='checkpoints/model_final.npz', load_path=None, strict=False, submit_batch_size=64, save_csv='submission.csv'):
    """
    mode='train'  -> trains, saves model.
    mode='test' -> loads saved model and runs test inference.
    """
    if mode == 'train':
        return train_eval(data_root=data_root, img_size=img_size, batch_size=batch_size, epochs=epochs, lr=lr, use_augment=use_augment, model_cls=model_cls, save_path=save_path)
    elif mode == 'test':
        lp = load_path or save_path
        return run_test_submit(data_root=data_root, img_size=img_size, batch_size=submit_batch_size, load_path=lp, model_cls=model_cls, strict=strict)
    else:
        raise ValueError("mode must be 'train' or 'submit'")


# ---- Sanity guard ----
try:
    _ = run_test_submit  # type: ignore[name-defined]
except NameError:
    raise NameError(
        "No function `run_test_submit` was found in the extracted notebook. "
        "Please define run_test_submit(...) in your notebook."
    )
